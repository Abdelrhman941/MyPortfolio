import { ArrowDown } from "lucide-react";

const Hero = () => {
  const skills = [
    "Machine Learning",
    "Deep Learning",
    "AI",
    "Data Science",
    "Python",
    "TensorFlow",
    "PyTorch",
    "NLP",
    "Computer Vision",
  ];

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-secondary to-background" />
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse animation-delay-1000" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Marquee Text Top */}
        <div className="overflow-hidden mb-8 opacity-20">
          <div className="flex gap-4 animate-marquee whitespace-nowrap">
            {[...skills, ...skills].map((skill, index) => (
              <span key={index} className="text-foreground text-sm">
                {skill} •
              </span>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="flex-1 space-y-6 animate-fade-in">
            <h1 className="text-5xl md:text-7xl font-display font-bold">
              <span className="text-foreground">Abdelrhman Ezzat</span>
            </h1>
            <h2 className="text-2xl md:text-3xl text-primary font-semibold">
              Data Scientist & AI Engineer
            </h2>
            <p className="text-xl text-muted-foreground max-w-xl">
              Transforming raw data into intelligent solutions.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <button
                onClick={() =>
                  document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })
                }
                className="px-8 py-3 bg-gradient-primary text-primary-foreground rounded-lg font-semibold hover:shadow-glow transition-all duration-300 hover:scale-105"
              >
                View Projects
              </button>
              <button
                onClick={() =>
                  document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
                }
                className="px-8 py-3 border-2 border-primary text-primary rounded-lg font-semibold hover:bg-primary/10 transition-all duration-300"
              >
                Get in Touch
              </button>
            </div>
          </div>

          {/* Profile Image */}
          <div className="flex-1 flex justify-center lg:justify-end animate-scale-in">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-primary rounded-full blur-2xl opacity-30 animate-pulse" />
              <div className="relative w-80 h-80 rounded-full overflow-hidden border-4 border-primary/50 shadow-glow">
                <img
                  src="https://abdelrhman941.github.io/MyPortfolio/assets/profile-B3qF5h4o.jpg"
                  alt="Abdelrhman Ezzat - Data Scientist & AI Engineer"
                  className="w-full h-full object-cover"
                  loading="eager"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Marquee Text Bottom */}
        <div className="overflow-hidden mt-8 opacity-20">
          <div className="flex gap-4 animate-marquee-reverse whitespace-nowrap">
            {[...skills, ...skills].map((skill, index) => (
              <span key={index} className="text-foreground text-sm">
                {skill} •
              </span>
            ))}
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ArrowDown className="text-primary" size={32} />
        </div>
      </div>
    </section>
  );
};

export default Hero;
