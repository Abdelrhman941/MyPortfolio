import { Brain, Code, Database, Eye } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const Services = () => {
  const services = [
    {
      icon: <Brain className="w-12 h-12 text-primary" />,
      title: "Machine Learning",
      description:
        "Building predictive models and algorithms that learn from data to make intelligent decisions and forecasts.",
    },
    {
      icon: <Eye className="w-12 h-12 text-primary" />,
      title: "Computer Vision",
      description:
        "Developing systems that can interpret and understand visual information from images and videos.",
    },
    {
      icon: <Code className="w-12 h-12 text-primary" />,
      title: "NLP Solutions",
      description:
        "Creating natural language processing systems for text analysis, sentiment detection, and language understanding.",
    },
    {
      icon: <Database className="w-12 h-12 text-primary" />,
      title: "Data Analysis",
      description:
        "Extracting meaningful insights from complex datasets to drive data-driven business decisions.",
    },
  ];

  return (
    <section id="services" className="py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-12">
          My <span className="text-primary">Services</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card
              key={index}
              className="bg-card border-border hover:border-primary transition-all duration-300 hover:shadow-glow group"
            >
              <CardHeader>
                <div className="mb-4 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>
                <CardTitle className="text-xl font-semibold text-foreground">
                  {service.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-muted-foreground">
                  {service.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
