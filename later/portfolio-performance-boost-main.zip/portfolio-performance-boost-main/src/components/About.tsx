const About = () => {
  return (
    <section id="about" className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-12">
          About <span className="text-primary">Me</span>
        </h2>
        <div className="max-w-3xl mx-auto">
          <p className="text-lg text-muted-foreground leading-relaxed mb-6">
            I'm a passionate Data Scientist and AI Engineer dedicated to leveraging cutting-edge
            technologies to solve complex real-world problems. With expertise in Machine Learning,
            Deep Learning, and AI, I transform raw data into actionable insights and intelligent
            solutions.
          </p>
          <p className="text-lg text-muted-foreground leading-relaxed">
            My experience spans across Natural Language Processing, Computer Vision, and developing
            robust AI systems using Python, TensorFlow, and PyTorch. I thrive on challenges that
            push the boundaries of what's possible with data and AI.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;
