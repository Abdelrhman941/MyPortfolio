import { Mail, MapPin, Phone } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const Contact = () => {
  const contactInfo = [
    {
      icon: <Phone className="w-6 h-6 text-primary" />,
      label: "Phone",
      value: "+20 123 456 7890",
      href: "tel:+201234567890",
    },
    {
      icon: <Mail className="w-6 h-6 text-primary" />,
      label: "Email",
      value: "abdelrhman.ezzat@example.com",
      href: "mailto:abdelrhman.ezzat@example.com",
    },
    {
      icon: <MapPin className="w-6 h-6 text-primary" />,
      label: "Location",
      value: "Cairo, Egypt",
      href: "#",
    },
  ];

  return (
    <section id="contact" className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-12">
          Get in <span className="text-primary">Touch</span>
        </h2>
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {contactInfo.map((item, index) => (
              <Card
                key={index}
                className="bg-card border-border hover:border-primary transition-all duration-300 hover:shadow-glow"
              >
                <CardContent className="p-6 text-center space-y-4">
                  <div className="flex justify-center">{item.icon}</div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{item.label}</p>
                    <a
                      href={item.href}
                      className="text-foreground font-semibold hover:text-primary transition-colors"
                    >
                      {item.value}
                    </a>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
