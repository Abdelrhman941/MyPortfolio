import { Badge } from "@/components/ui/badge";

const Skills = () => {
  const skillCategories = [
    {
      category: "Programming Languages",
      skills: ["Python", "R", "SQL", "JavaScript"],
    },
    {
      category: "ML/DL Frameworks",
      skills: ["TensorFlow", "PyTorch", "Keras", "Scikit-learn"],
    },
    {
      category: "Data Tools",
      skills: ["Pandas", "NumPy", "Matplotlib", "Seaborn"],
    },
    {
      category: "AI Specializations",
      skills: ["NLP", "Computer Vision", "Deep Learning", "Reinforcement Learning"],
    },
  ];

  return (
    <section id="skills" className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-12">
          Technical <span className="text-primary">Skills</span>
        </h2>
        <div className="max-w-4xl mx-auto space-y-8">
          {skillCategories.map((category, index) => (
            <div key={index} className="space-y-4">
              <h3 className="text-xl font-semibold text-foreground">{category.category}</h3>
              <div className="flex flex-wrap gap-3">
                {category.skills.map((skill, skillIndex) => (
                  <Badge
                    key={skillIndex}
                    variant="secondary"
                    className="px-4 py-2 text-base bg-card border border-primary/30 hover:border-primary hover:shadow-glow transition-all duration-300 cursor-default"
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
