import { GoogleGenAI } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";

let aiClient: GoogleGenAI | null = null;

const getClient = () => {
  if (!aiClient) {
    if (!process.env.API_KEY) {
      console.error("API_KEY is missing from environment variables.");
      throw new Error("API Key not found");
    }
    aiClient = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
  return aiClient;
};

export const sendMessageToGemini = async (
  message: string,
  history: { role: string; parts: { text: string }[] }[]
): Promise<string> => {
  try {
    const ai = getClient();
    
    // We use gemini-2.5-flash for fast, responsive chat interactions
    const model = 'gemini-2.5-flash';

    const chat = ai.chats.create({
      model: model,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
      history: history, 
    });

    const response = await chat.sendMessage({
      message: message
    });

    // Directly access .text property as per guidelines
    const text = response.text;
    
    if (!text) {
      throw new Error("No response text generated");
    }

    return text;
  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    throw error;
  }
};
