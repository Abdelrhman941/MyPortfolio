import React from 'react';
import { ArrowRight, Github, Linkedin, Mail } from 'lucide-react';
import { PERSONAL_INFO } from '../constants';

const Hero: React.FC = () => {
  return (
    <section id="home" className="min-h-screen flex items-center pt-16 relative overflow-hidden">
      {/* Background Gradient Blob */}
      <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-primary/20 rounded-full blur-[100px] -z-10 animate-pulse" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[400px] h-[400px] bg-purple-500/20 rounded-full blur-[100px] -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col-reverse md:flex-row items-center gap-12">
        <div className="flex-1 space-y-8 text-center md:text-left">
          <div className="space-y-4">
            <h2 className="text-primary font-semibold tracking-wide uppercase">Frontend Developer</h2>
            <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight">
              Building the <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-400">Future Web</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto md:mx-0">
              {PERSONAL_INFO.tagline}
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center justify-center md:justify-start gap-4">
            <a 
              href="#projects" 
              className="px-8 py-3 bg-primary text-white rounded-full font-medium hover:bg-blue-600 transition-colors flex items-center gap-2"
            >
              View Projects <ArrowRight size={20} />
            </a>
            <a 
              href="#contact" 
              className="px-8 py-3 border border-gray-600 text-gray-300 rounded-full font-medium hover:border-white hover:text-white transition-colors"
            >
              Contact Me
            </a>
          </div>

          <div className="flex items-center justify-center md:justify-start gap-6 pt-4">
            <a href={PERSONAL_INFO.github} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Github size={24} />
            </a>
            <a href={PERSONAL_INFO.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Linkedin size={24} />
            </a>
            <a href={`mailto:${PERSONAL_INFO.email}`} className="text-gray-400 hover:text-white transition-colors">
              <Mail size={24} />
            </a>
          </div>
        </div>

        <div className="flex-1 flex justify-center">
          <div className="relative w-64 h-64 md:w-96 md:h-96">
            <div className="absolute inset-0 bg-gradient-to-tr from-primary to-purple-500 rounded-full opacity-20 animate-spin-slow" style={{ animationDuration: '10s' }} />
            <img 
              src="https://picsum.photos/400/400" 
              alt={PERSONAL_INFO.name} 
              className="relative w-full h-full object-cover rounded-full border-4 border-surface shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;