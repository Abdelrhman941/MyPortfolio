import { Project, Skill, NavItem } from './types';

export const PERSONAL_INFO = {
  name: "Abdelrhman",
  title: "Senior Frontend Engineer",
  tagline: "Building performant, accessible, and beautiful web experiences.",
  about: "I am a passionate frontend engineer with a knack for crafting clean, user-friendly interfaces. With deep expertise in the React ecosystem and modern performance optimization techniques, I turn complex requirements into seamless digital products. I advocate for clean code, accessibility, and exceptional user experience.",
  email: "contact@example.com",
  github: "https://github.com/Abdelrhman941",
  linkedin: "https://linkedin.com/in/example",
  location: "Cairo, Egypt"
};

export const NAV_ITEMS: NavItem[] = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Contact', href: '#contact' },
];

export const SKILLS: Skill[] = [
  { name: 'React / Next.js', category: 'Frontend', level: 95 },
  { name: 'TypeScript', category: 'Frontend', level: 90 },
  { name: 'Tailwind CSS', category: 'Frontend', level: 95 },
  { name: 'Node.js', category: 'Backend', level: 75 },
  { name: 'GraphQL', category: 'Backend', level: 80 },
  { name: 'Git / CI/CD', category: 'Tools', level: 85 },
  { name: 'Performance Opt.', category: 'Tools', level: 90 },
  { name: 'Gemini AI API', category: 'Tools', level: 80 },
];

export const PROJECTS: Project[] = [
  {
    id: '1',
    title: 'E-Commerce Dashboard',
    description: 'A high-performance analytics dashboard for e-commerce stores featuring real-time data visualization using Recharts and React Query.',
    tags: ['React', 'TypeScript', 'Recharts', 'Supabase'],
    imageUrl: 'https://picsum.photos/800/600?random=1',
    demoUrl: '#',
    repoUrl: '#'
  },
  {
    id: '2',
    title: 'AI Content Generator',
    description: 'A SaaS platform integrating Google Gemini API to help users generate marketing copy and blog posts with a seamless rich-text editor.',
    tags: ['Next.js', 'Gemini API', 'Tailwind', 'Stripe'],
    imageUrl: 'https://picsum.photos/800/600?random=2',
    demoUrl: '#',
    repoUrl: '#'
  },
  {
    id: '3',
    title: 'Task Master App',
    description: 'A collaborative task management tool with drag-and-drop functionality, offline support, and optimistic UI updates.',
    tags: ['React', 'Redux Toolkit', 'PWA', 'Firebase'],
    imageUrl: 'https://picsum.photos/800/600?random=3',
    demoUrl: '#',
    repoUrl: '#'
  }
];

export const SYSTEM_INSTRUCTION = `You are a helpful AI assistant for Abdelrhman's portfolio website. 
Your goal is to answer questions about Abdelrhman based on the following context:
${PERSONAL_INFO.about}
Skills: ${SKILLS.map(s => s.name).join(', ')}.
Projects: ${PROJECTS.map(p => p.title).join(', ')}.
Be professional, concise, and friendly. If you don't know an answer, suggest the user contact him directly via the contact form.`;
