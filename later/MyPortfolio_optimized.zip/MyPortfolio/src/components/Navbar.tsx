import cvFile from '@/resume/Abdelrhman_Ezzat_CV.pdf';
import React, { useEffect, useState } from 'react';

const NAV_LINKS = [
  { href: '#about', label: 'About' },
  { href: '#services', label: 'Services' },
  { href: '#skills', label: 'Skills' },
  { href: '#projects', label: 'Projects' },
];

const useScrollSpy = (sectionIds: string[], offset: number) => {
  const [activeSection, setActiveSection] = useState<string | null>('#cover');

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + offset;

      let currentSectionId = null;
      for (const id of sectionIds) {
        const element = document.getElementById(id.substring(1));
        if (element) {
          if (element.offsetTop <= scrollPosition) {
            currentSectionId = id;
          }
        }
      }
      setActiveSection(currentSectionId);
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, [sectionIds, offset]);

  return activeSection;
};

const Navbar: React.FC = () => {
  // Add a ref to the mobile menu button for focus management
  const menuButtonRef = React.useRef<HTMLButtonElement>(null);
  const [isOpen, setIsOpen] = useState(false);
  const allLinks = [...NAV_LINKS, { href: '#contact', label: 'Contact' }, {href: '#cover', label: 'Cover'}];
  const activeSection = useScrollSpy(allLinks.map(l => l.href), 150);

  const NavLink: React.FC<{ href: string; children: React.ReactNode; isMobile?: boolean; role?: string }> = ({ href, children, isMobile, role = 'menuitem' }) => {
    const isActive = activeSection === href;
    return (
      <a
        href={href}
        onClick={() => isMobile && setIsOpen(false)}
        className={`px-3 py-2 text-sm font-medium transition-colors duration-300 ${isActive ? 'text-white' : 'text-gray-400 hover:text-white'}`}
        role={role}
      >
        {children}
      </a>
    );
  };

  return (
    <>
      <nav className="fixed top-4 left-4 right-4 z-50" aria-label="Main navigation">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-2 bg-black/30 backdrop-blur-xl border border-white/10 rounded-full shadow-lg transition-all duration-300">
          <div className="relative flex justify-between items-center">
              <a href="#cover" className="text-xl font-bold text-white pl-2" style={{textShadow: '0 0 5px rgba(255,255,255,0.3)'}} aria-label="Go to cover section">
              AE.
            </a>

            <div className="hidden md:absolute md:left-1/2 md:top-1/2 md:transform md:-translate-x-1/2 md:-translate-y-1/2 md:flex md:items-center" role="menubar">
               {NAV_LINKS.map(link => <NavLink key={link.href} href={link.href}>{link.label}</NavLink>)}
            </div>

            <div className="hidden md:flex items-center space-x-4">
              <a href="#contact" className="px-3 py-2 text-sm font-medium text-gray-300 hover:text-white transition-colors" role="menuitem">Contact</a>
              <a href={cvFile} download className="px-4 py-2 text-sm font-semibold bg-white text-black rounded-full hover:bg-gray-200 transition-all duration-300 transform hover:scale-105" role="menuitem">
                Download CV
              </a>
            </div>

            <button
	              ref={menuButtonRef}
	              className="md:hidden text-white focus:outline-none z-20"
	              onClick={() => setIsOpen(!isOpen)}
	              aria-label={isOpen ? "Close mobile menu" : "Open mobile menu"}
	              aria-expanded={isOpen}
	              aria-controls="mobile-menu"
	            >
              <i className={`fas ${isOpen ? 'fa-times' : 'fa-bars'} text-xl transition-transform duration-300`}></i>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
	        id="mobile-menu"
	        className={`md:hidden fixed inset-0 z-40 transition-all duration-500 ease-in-out ${isOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}
	        onClick={() => setIsOpen(false)}
	        role="dialog"
	        aria-modal="true"
	        aria-labelledby="mobile-menu-title"
	        tabIndex={-1}
	      >
        <div className={`absolute inset-0 bg-black/90 backdrop-blur-xl transition-all duration-500 ${isOpen ? 'opacity-100' : 'opacity-0'}`}></div>
        <div className={`relative flex flex-col items-center justify-center h-full transition-transform duration-500 ease-out ${isOpen ? 'translate-y-0 scale-100' : '-translate-y-10 scale-95'}`} onClick={(e) => e.stopPropagation()} role="menu">
            <div className="flex flex-col items-center justify-center space-y-6 text-lg font-medium" role="none">
              {[...NAV_LINKS, { href: '#contact', label: 'Contact' }].map(link => <NavLink key={link.href} href={link.href} isMobile role="menuitem">{link.label}</NavLink>)}
            </div>
            <a href={cvFile} download className="mt-8 px-6 py-3 text-base font-semibold bg-white text-black rounded-full hover:bg-gray-200 transition-colors" role="menuitem">
              Download CV
            </a>
        </div>
      </div>
    </>
  );
};

export default Navbar;
