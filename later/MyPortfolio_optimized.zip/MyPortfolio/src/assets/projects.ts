// Project images - using direct paths from public folder with base path
export const projectImages = {
  traffic: '/MyPortfolio/projects/Traffic_Sign_Recognition_System.png',
  dqn: '/MyPortfolio/projects/2048_Deep_Q-Network_Playground.png',
  vehicle: '/MyPortfolio/projects/Vehicle_Detection_System.png',
  sports: '/MyPortfolio/projects/Sports%20Popularity%20Analysis%20and%20Forecasting.png',
  nlp: '/MyPortfolio/projects/Natural%20Language%20Auto%20Correction%20System.jpg'
};
